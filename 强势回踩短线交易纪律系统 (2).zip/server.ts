import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { initStorage, safeWriteCSV, parseCSV, loadHistoryKLine, checkHistoryStatus, saveHistoryKLine } from "./server/storage";
import { evaluateStock, isMainBoard, shouldExclude, auditBuyTrade } from "./server/rules";
import { fetchTopTurnoverStocks, fetchStockKLines, batchFetchKLines, generateMockTopStocks, generateMockHistoryKLines } from "./server/market";
import { Stock, TradeLog, StockGroup, StockStage, Position, AccountState, ReviewReport } from "./src/types";

// 初始化存储目录
initStorage();

const app = express();
const PORT = 3000;

app.use(express.json());

// API 路由定义之前，确保我们可以解析各种表单与数据形式
app.use(express.urlencoded({ extended: true }));

// CSV 路径定义
const WATCHLIST_CSV = path.join(process.cwd(), "data", "watchlist.csv");
const TRADE_LOG_CSV = path.join(process.cwd(), "data", "trades", "trade_log.csv");
const TRADE_LOG_SIM_CSV = path.join(process.cwd(), "data", "trades", "trade_log_sim.csv");
const TRADE_LOG_REAL_CSV = path.join(process.cwd(), "data", "trades", "trade_log_real.csv");
const SETTINGS_JSON = path.join(process.cwd(), "data", "runtime", "settings.json");

interface Settings {
  initialCash: number;
  realInitialCash: number;
  currentMode: "simulation" | "real";
  commissionRate: number;
  minCommission: number;
  stampDutyRate: number;
  transferFeeRate: number;
}

function getSettings(): Settings {
  try {
    if (fs.existsSync(SETTINGS_JSON)) {
      const settings = JSON.parse(fs.readFileSync(SETTINGS_JSON, "utf8"));
      return {
        initialCash: Number(settings.initialCash) || 100000,
        realInitialCash: Number(settings.realInitialCash) || 100000,
        currentMode: settings.currentMode === "real" ? "real" : "simulation",
        commissionRate: settings.commissionRate !== undefined ? Number(settings.commissionRate) : 0.0003,
        minCommission: settings.minCommission !== undefined ? Number(settings.minCommission) : 5.0,
        stampDutyRate: settings.stampDutyRate !== undefined ? Number(settings.stampDutyRate) : 0.0005,
        transferFeeRate: settings.transferFeeRate !== undefined ? Number(settings.transferFeeRate) : 0.00001
      };
    }
  } catch (err) {
    console.error("加载设置失败:", err);
  }
  return {
    initialCash: 100000,
    realInitialCash: 100000,
    currentMode: "simulation",
    commissionRate: 0.0003,
    minCommission: 5.0,
    stampDutyRate: 0.0005,
    transferFeeRate: 0.00001
  };
}

function saveSettings(updates: Partial<Settings>) {
  try {
    const current = getSettings();
    const updated = { ...current, ...updates };
    fs.writeFileSync(SETTINGS_JSON, JSON.stringify(updated, null, 2), "utf8");
  } catch (err) {
    console.error("保存设置失败:", err);
  }
}

// 辅助：加载可用现金设置
function getInitialCash(mode?: "simulation" | "real"): number {
  const settings = getSettings();
  const activeMode = mode || settings.currentMode;
  return activeMode === "real" ? settings.realInitialCash : settings.initialCash;
}

// 辅助：加载 Watchlist CSV
function loadWatchlist(): Stock[] {
  if (!fs.existsSync(WATCHLIST_CSV)) return [];
  try {
    const content = fs.readFileSync(WATCHLIST_CSV, "utf8");
    const parsed = parseCSV(content);
    return parsed.map((item: any) => ({
      code: String(item.code),
      name: String(item.name),
      price: Number(item.price) || 0,
      pct: Number(item.pct) || 0,
      volume: Number(item.volume) || 0,
      rank: Number(item.rank) || 0,
      ma5: Number(item.ma5) || 0,
      ma10: Number(item.ma10) || 0,
      ma20: Number(item.ma20) || 0,
      deviation5: Number(item.deviation5) || 0,
      bigCandlePct: Number(item.bigCandlePct) || 0,
      ma5Upward: item.ma5Upward === true || item.ma5Upward === "true",
      canBuy: item.canBuy === true || item.canBuy === "true",
      group: (item.group as StockGroup) || "初筛",
      stage: (item.stage as StockStage) || "缺少历史K线",
      riskLevel: item.riskLevel || "normal",
      reason: item.reason || "",
      reminder: item.reminder || "",
      historyStatus: item.historyStatus || "缺少历史K线",
      lastUpdated: item.lastUpdated || "",
      remark: item.remark || ""
    }));
  } catch (err) {
    console.error("加载 Watchlist 失败:", err);
    return [];
  }
}

// 辅助：写入 Watchlist CSV
function writeWatchlist(stocks: Stock[]) {
  const headers = [
    "code", "name", "price", "pct", "volume", "rank", "ma5", "ma10", "ma20",
    "deviation5", "bigCandlePct", "ma5Upward", "canBuy", "group", "stage",
    "riskLevel", "reason", "reminder", "historyStatus", "lastUpdated", "remark"
  ];
  safeWriteCSV(WATCHLIST_CSV, headers, stocks);
}

// 获取具体交易日志路径
function getTradeLogPath(mode: "simulation" | "real"): string {
  if (mode === "real") {
    return TRADE_LOG_REAL_CSV;
  }
  // 如果是模拟，并且 data/trades/trade_log_sim.csv 还不存在，但 trade_log.csv 存在，则复制过去做迁移
  if (!fs.existsSync(TRADE_LOG_SIM_CSV) && fs.existsSync(TRADE_LOG_CSV)) {
    try {
      fs.copyFileSync(TRADE_LOG_CSV, TRADE_LOG_SIM_CSV);
    } catch (e) {
      console.error("复制旧模拟交易日志失败:", e);
    }
  }
  return TRADE_LOG_SIM_CSV;
}

// 辅助：加载交易日志 CSV
function loadTrades(mode: "simulation" | "real" = "simulation"): TradeLog[] {
  const csvPath = getTradeLogPath(mode);
  if (!fs.existsSync(csvPath)) return [];
  try {
    const content = fs.readFileSync(csvPath, "utf8");
    const parsed = parseCSV(content);
    return parsed.map((item: any) => ({
      id: String(item.id),
      code: String(item.code),
      name: String(item.name),
      type: item.type === "SELL" ? "SELL" : "BUY",
      date: String(item.date),
      time: String(item.time),
      price: Number(item.price) || 0,
      quantity: Number(item.quantity) || 0,
      amount: Number(item.amount) || 0,
      commission: Number(item.commission) || 0,
      stampDuty: Number(item.stampDuty) || 0,
      transferFee: Number(item.transferFee) || 0,
      totalFee: Number(item.totalFee) || 0,
      reason: item.reason || "",
      remark: item.remark || "",
      rulesConclusion: item.rulesConclusion || "其他",
      violationTags: item.violationTags ? (typeof item.violationTags === "string" ? JSON.parse(item.violationTags) : item.violationTags) : [],
      snapshot: {
        group: item.snapshot_group || "初筛",
        stage: item.snapshot_stage || "缺少历史K线",
        ma5: Number(item.snapshot_ma5) || 0,
        deviation5: Number(item.snapshot_deviation5) || 0,
        bigCandlePct: Number(item.snapshot_bigCandlePct) || 0,
        ma5Upward: item.snapshot_ma5Upward === true || item.snapshot_ma5Upward === "true",
        cashSufficient: item.snapshot_cashSufficient === true || item.snapshot_cashSufficient === "true",
        inTradingTime: item.snapshot_inTradingTime === true || item.snapshot_inTradingTime === "true"
      }
    }));
  } catch (err) {
    console.error(`加载 ${mode} 交易日志失败:`, err);
    return [];
  }
}

// 辅助：写入交易日志 CSV
function writeTrades(trades: TradeLog[], mode: "simulation" | "real" = "simulation") {
  const csvPath = getTradeLogPath(mode);
  const headers = [
    "id", "code", "name", "type", "date", "time", "price", "quantity", "amount",
    "commission", "stampDuty", "transferFee", "totalFee", "reason", "remark",
    "rulesConclusion", "violationTags", "snapshot_group", "snapshot_stage",
    "snapshot_ma5", "snapshot_deviation5", "snapshot_bigCandlePct",
    "snapshot_ma5Upward", "snapshot_cashSufficient", "snapshot_inTradingTime"
  ];
  
  const flattened = trades.map(t => ({
    id: t.id,
    code: t.code,
    name: t.name,
    type: t.type,
    date: t.date,
    time: t.time,
    price: t.price,
    quantity: t.quantity,
    amount: t.amount,
    commission: t.commission,
    stampDuty: t.stampDuty,
    transferFee: t.transferFee,
    totalFee: t.totalFee,
    reason: t.reason,
    remark: t.remark,
    rulesConclusion: t.rulesConclusion,
    violationTags: JSON.stringify(t.violationTags),
    snapshot_group: t.snapshot.group,
    snapshot_stage: t.snapshot.stage,
    snapshot_ma5: t.snapshot.ma5,
    snapshot_deviation5: t.snapshot.deviation5,
    snapshot_bigCandlePct: t.snapshot.bigCandlePct,
    snapshot_ma5Upward: t.snapshot.ma5Upward,
    snapshot_cashSufficient: t.snapshot.cashSufficient,
    snapshot_inTradingTime: t.snapshot.inTradingTime
  }));

  safeWriteCSV(csvPath, headers, flattened);
}

// ==========================================
// API 接口实现
// ==========================================

// 1. 获取账户状态与持仓 (Portfolio)
app.get("/api/portfolio", async (req, res) => {
  try {
    const mode = (req.query.mode as "simulation" | "real") || getSettings().currentMode;
    const trades = loadTrades(mode);
    const watchlist = loadWatchlist();
    const initialCash = getInitialCash(mode);
    
    // 创建现价与指标缓存映射
    const priceMap: Record<string, number> = {};
    const maMap: Record<string, number> = {};
    const devMap: Record<string, number> = {};
    const pctMap: Record<string, number> = {};
    
    watchlist.forEach(s => {
      priceMap[s.code] = s.price;
      maMap[s.code] = s.ma5;
      devMap[s.code] = s.deviation5;
      pctMap[s.code] = s.pct || 0;
    });

    // 从交易流水推导持仓
    const activePositions: Record<string, Position> = {};
    const firstPurchaseDates: Record<string, string> = {};
    let cashBalance = initialCash;
    let totalRealizedPnL = 0;

    // 排序交易流水
    const sortedTrades = [...trades].sort((a, b) => {
      const dateCompare = a.date.localeCompare(b.date);
      if (dateCompare !== 0) return dateCompare;
      return a.time.localeCompare(b.time);
    });

    for (const trade of sortedTrades) {
      const tradeAmount = trade.price * trade.quantity;
      const tradeFee = trade.totalFee;

      if (trade.type === "BUY") {
        cashBalance -= (tradeAmount + tradeFee);
        
        if (!activePositions[trade.code]) {
          firstPurchaseDates[trade.code] = trade.date;
          activePositions[trade.code] = {
            code: trade.code,
            name: trade.name,
            quantity: trade.quantity,
            availableQuantity: trade.quantity, // 简化不设 T+1 锁，由交易控制
            avgCost: Number(((tradeAmount + tradeFee) / trade.quantity).toFixed(4)),
            currentPrice: priceMap[trade.code] || trade.price,
            marketValue: 0,
            floatingPnL: 0,
            floatingPnLPct: 0,
            ma5: maMap[trade.code] || 0,
            deviation5: devMap[trade.code] || 0,
            holdDays: 1, // 后面会根据首买日期计算
            advice: "趋势未破，继续持有观察",
            riskLevel: "normal"
          };
        } else {
          const p = activePositions[trade.code];
          const prevTotalCost = p.avgCost * p.quantity;
          const newQty = p.quantity + trade.quantity;
          const newTotalCost = prevTotalCost + tradeAmount + tradeFee;
          p.quantity = newQty;
          p.availableQuantity = newQty;
          p.avgCost = Number((newTotalCost / newQty).toFixed(4));
        }
      } else if (trade.type === "SELL") {
        cashBalance += (tradeAmount - tradeFee);
        
        if (activePositions[trade.code]) {
          const p = activePositions[trade.code];
          
          // 计算该笔卖出实现的盈利
          const costOfSoldShares = p.avgCost * trade.quantity;
          const profitOnThisSell = tradeAmount - tradeFee - costOfSoldShares;
          totalRealizedPnL += profitOnThisSell;

          const remainingQty = p.quantity - trade.quantity;
          if (remainingQty <= 0) {
            delete activePositions[trade.code];
            delete firstPurchaseDates[trade.code];
          } else {
            p.quantity = remainingQty;
            p.availableQuantity = remainingQty;
          }
        }
      }
    }

    const todayStr = new Date().toISOString().split("T")[0];
    const getDaysBetween = (dateStr1: string, dateStr2: string): number => {
      try {
        const d1 = new Date(dateStr1);
        const d2 = new Date(dateStr2);
        const diffTime = Math.abs(d2.getTime() - d1.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays || 1;
      } catch (e) {
        return 1;
      }
    };

    // 为每个持仓设置真实的持股天数
    Object.keys(activePositions).forEach(code => {
      const p = activePositions[code];
      const buyDate = firstPurchaseDates[code] || todayStr;
      p.holdDays = getDaysBetween(buyDate, todayStr);
    });

    // 组合当前价格和最终指标
    const positionsList: Position[] = [];
    let holdingValue = 0;
    let totalFloatingPnL = 0;

    for (const code of Object.keys(activePositions)) {
      const p = activePositions[code];
      const livePrice = priceMap[code] || p.currentPrice;
      p.currentPrice = livePrice;
      p.marketValue = Number((livePrice * p.quantity).toFixed(2));
      p.floatingPnL = Number((p.marketValue - (p.avgCost * p.quantity)).toFixed(2));
      p.floatingPnLPct = Number(((p.floatingPnL / (p.avgCost * p.quantity)) * 100).toFixed(2));
      
      holdingValue += p.marketValue;
      totalFloatingPnL += p.floatingPnL;

      // 风控提醒与操作建议
      p.ma5 = maMap[code] || p.ma5;
      if (p.ma5 > 0) {
        p.deviation5 = Number((((livePrice - p.ma5) / p.ma5) * 100).toFixed(2));
      }
      
      if (livePrice < p.ma5) {
        p.advice = "跌破5日线，考虑减仓或卖出！";
        p.riskLevel = "danger";
      } else if (p.deviation5 > 7.0) {
        p.advice = "偏离5日线过远 (>7%)，注意逢高止盈！";
        p.riskLevel = "warning";
      } else {
        p.advice = "趋势健在，可继续持有。";
        p.riskLevel = "normal";
      }

      positionsList.push(p);
    }

    let todayPnL = 0;
    for (const code of Object.keys(activePositions)) {
      const p = activePositions[code];
      const pct = pctMap[code] || 0;
      // 今日盈亏 = 今日市值 - 昨日市值 = 市值 - (市值 / (1 + pct / 100))
      const yesterdayValue = p.marketValue / (1 + (pct / 100));
      const stockTodayPnL = p.marketValue - yesterdayValue;
      todayPnL += stockTodayPnL;
    }

    const totalAssets = Number((cashBalance + holdingValue).toFixed(2));
    const totalPnL = Number((totalAssets - initialCash).toFixed(2));
    const totalReturnPct = initialCash > 0 ? Number(((totalPnL / initialCash) * 100).toFixed(2)) : 0;

    const accountState: AccountState = {
      initialCash,
      availableCash: Number(cashBalance.toFixed(2)),
      holdingValue: Number(holdingValue.toFixed(2)),
      totalAssets,
      realizedPnL: Number(totalRealizedPnL.toFixed(2)),
      floatingPnL: Number(totalFloatingPnL.toFixed(2)),
      totalPnL,
      totalReturnPct,
      todayPnL: Number(todayPnL.toFixed(2))
    };

    res.json({ accountState, positions: positionsList });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. 获取与更新账户整体配置 (模拟本金、实盘本金、当前模式)
app.get("/api/settings", (req, res) => {
  const settings = getSettings();
  res.json(settings);
});

app.post("/api/settings", (req, res) => {
  const { initialCash, realInitialCash, currentMode, commissionRate, minCommission, stampDutyRate, transferFeeRate } = req.body;
  const updates: any = {};
  if (typeof initialCash === "number" && initialCash > 0) updates.initialCash = initialCash;
  if (typeof realInitialCash === "number" && realInitialCash > 0) updates.realInitialCash = realInitialCash;
  if (currentMode === "simulation" || currentMode === "real") updates.currentMode = currentMode;
  if (typeof commissionRate === "number" && commissionRate >= 0) updates.commissionRate = commissionRate;
  if (typeof minCommission === "number" && minCommission >= 0) updates.minCommission = minCommission;
  if (typeof stampDutyRate === "number" && stampDutyRate >= 0) updates.stampDutyRate = stampDutyRate;
  if (typeof transferFeeRate === "number" && transferFeeRate >= 0) updates.transferFeeRate = transferFeeRate;
  
  saveSettings(updates);
  res.json({ success: true, settings: { ...getSettings(), ...updates } });
});

app.post("/api/account/settings", (req, res) => {
  const { initialCash } = req.body;
  if (typeof initialCash !== "number" || initialCash <= 0) {
    return res.status(400).json({ error: "初始资金输入有误" });
  }
  const settings = getSettings();
  if (settings.currentMode === "real") {
    saveSettings({ realInitialCash: initialCash });
  } else {
    saveSettings({ initialCash });
  }
  res.json({ success: true, initialCash });
});

// 3. 获取 Watchlist
app.get("/api/watchlist", (req, res) => {
  const list = loadWatchlist();
  res.json({ list });
});

// 4. 生成或刷新初筛股票池
app.post("/api/watchlist/generate", async (req, res) => {
  try {
    const availableCash = getInitialCash();
    const rawList = await fetchTopTurnoverStocks();
    
    // 过滤排除名单和非主板股票，保留前 30
    const filtered: any[] = [];
    for (const item of rawList) {
      const exclusion = shouldExclude(item.code, item.name);
      if (!exclusion.exclude) {
        filtered.push(item);
      }
      if (filtered.length >= 30) break;
    }

    const currentWatchlist = loadWatchlist();
    const oldRemarksMap: Record<string, string> = {};
    currentWatchlist.forEach(s => {
      if (s.remark) oldRemarksMap[s.code] = s.remark;
    });

    // 构建全新初筛股票池列表
    const newWatchlist: Stock[] = [];
    for (const item of filtered) {
      // 读取本地缓存的历史 K 线
      const historyKLine = loadHistoryKLine(item.code);
      const evalResult = evaluateStock(item.code, item.name, item.price, historyKLine, availableCash);

      newWatchlist.push({
        code: item.code,
        name: item.name,
        price: item.price,
        pct: item.pct,
        volume: item.volume,
        rank: item.rank,
        ma5: evalResult.indicators.ma5,
        ma10: evalResult.indicators.ma10,
        ma20: evalResult.indicators.ma20,
        deviation5: evalResult.indicators.deviation5,
        bigCandlePct: evalResult.indicators.bigCandlePct,
        ma5Upward: evalResult.indicators.ma5Upward,
        canBuy: evalResult.canBuy,
        group: evalResult.group,
        stage: evalResult.stage,
        riskLevel: evalResult.riskLevel,
        reason: evalResult.reason,
        reminder: evalResult.reminder,
        historyStatus: evalResult.indicators.historyStatus,
        lastUpdated: new Date().toISOString(),
        remark: oldRemarksMap[item.code] || ""
      });
    }

    writeWatchlist(newWatchlist);
    res.json({ success: true, list: newWatchlist });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. 补充单只或全部股票的历史K线
app.post("/api/watchlist/fetch-history", async (req, res) => {
  const { code, fetchAll } = req.body;
  const availableCash = getInitialCash();
  const list = loadWatchlist();
  
  const codesToFetch = fetchAll 
    ? list.map(s => s.code)
    : (code ? [code] : list.filter(s => s.historyStatus !== "已有缓存").map(s => s.code));

  if (codesToFetch.length === 0) {
    return res.json({ success: true, message: "无需更新历史K线", list });
  }

  try {
    await batchFetchKLines(codesToFetch);
    
    // 重新计算并更新 Watchlist 中的状态
    const updatedList = list.map(s => {
      if (codesToFetch.includes(s.code)) {
        const historyKLine = loadHistoryKLine(s.code);
        const evalResult = evaluateStock(s.code, s.name, s.price, historyKLine, availableCash);
        return {
          ...s,
          ma5: evalResult.indicators.ma5,
          ma10: evalResult.indicators.ma10,
          ma20: evalResult.indicators.ma20,
          deviation5: evalResult.indicators.deviation5,
          bigCandlePct: evalResult.indicators.bigCandlePct,
          ma5Upward: evalResult.indicators.ma5Upward,
          canBuy: evalResult.canBuy,
          group: evalResult.group,
          stage: evalResult.stage,
          riskLevel: evalResult.riskLevel,
          reason: evalResult.reason,
          reminder: evalResult.reminder,
          historyStatus: evalResult.indicators.historyStatus,
          lastUpdated: new Date().toISOString()
        };
      }
      return s;
    });

    writeWatchlist(updatedList);
    res.json({ success: true, list: updatedList });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. 盘中轻量刷新实时价格与偏离率
app.post("/api/watchlist/refresh-quotes", async (req, res) => {
  try {
    const list = loadWatchlist();
    if (list.length === 0) {
      return res.json({ success: true, list });
    }

    const availableCash = getInitialCash();
    
    // 抓取实时最新数据 (带 fallback 模拟)
    const rawList = await fetchTopTurnoverStocks();
    const rawPriceMap: Record<string, { price: number; pct: number }> = {};
    rawList.forEach(r => {
      rawPriceMap[r.code] = { price: r.price, pct: r.pct };
    });

    const updatedList = list.map(s => {
      const liveData = rawPriceMap[s.code];
      const livePrice = liveData ? liveData.price : s.price;
      const livePct = liveData ? liveData.pct : s.pct;

      const historyKLine = loadHistoryKLine(s.code);
      const evalResult = evaluateStock(s.code, s.name, livePrice, historyKLine, availableCash);

      return {
        ...s,
        price: livePrice,
        pct: livePct,
        ma5: evalResult.indicators.ma5,
        ma10: evalResult.indicators.ma10,
        ma20: evalResult.indicators.ma20,
        deviation5: evalResult.indicators.deviation5,
        bigCandlePct: evalResult.indicators.bigCandlePct,
        ma5Upward: evalResult.indicators.ma5Upward,
        canBuy: evalResult.canBuy,
        group: evalResult.group,
        stage: evalResult.stage,
        riskLevel: evalResult.riskLevel,
        reason: evalResult.reason,
        reminder: evalResult.reminder,
        historyStatus: evalResult.indicators.historyStatus,
        lastUpdated: new Date().toISOString()
      };
    });

    writeWatchlist(updatedList);
    res.json({ success: true, list: updatedList });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. 更新单只股票备注或手动调整其分组
app.post("/api/watchlist/update-stock", (req, res) => {
  const { code, group, remark } = req.body;
  if (!code) return res.status(400).json({ error: "股票代码缺失" });

  const list = loadWatchlist();
  const idx = list.findIndex(s => s.code === code);
  if (idx === -1) return res.status(404).json({ error: "股票未在列表中" });

  if (group) list[idx].group = group as StockGroup;
  if (remark !== undefined) list[idx].remark = remark;
  list[idx].lastUpdated = new Date().toISOString();

  writeWatchlist(list);
  res.json({ success: true, stock: list[idx] });
});

// 8. 获取 K 线数据供图表绘制
app.get("/api/history/:code", async (req, res) => {
  const { code } = req.params;
  let rows = loadHistoryKLine(code);
  
  if (rows.length === 0) {
    // 自动抓取并保存
    try {
      rows = await fetchStockKLines(code, 40);
      if (rows.length > 0) {
        saveHistoryKLine(code, rows);
      }
    } catch (err) {
      console.error("抓取失败:", err);
    }
  }

  // 加上 MA 计算
  if (rows.length > 0) {
    const resultWithMAs = rows.map((r, i) => {
      const getMA = (arr: any[], idx: number, periods: number): number => {
        if (idx < periods - 1) return 0;
        const slice = arr.slice(idx - periods + 1, idx + 1);
        const sum = slice.reduce((acc, item) => acc + Number(item.close), 0);
        return Number((sum / periods).toFixed(2));
      };
      return {
        ...r,
        ma5: getMA(rows, i, 5),
        ma10: getMA(rows, i, 10),
        ma20: getMA(rows, i, 20)
      };
    });
    return res.json({ klines: resultWithMAs });
  }

  res.json({ klines: [] });
});

// 9. 获取交易历史
app.get("/api/trades", (req, res) => {
  const mode = (req.query.mode as "simulation" | "real") || getSettings().currentMode;
  const list = loadTrades(mode);
  res.json({ list });
});

// 10. 执行交易 (买入或卖出)
app.post("/api/trades/execute", async (req, res) => {
  const { code, name, type, price, quantity, reason, remark } = req.body;
  const mode = (req.body.mode as "simulation" | "real") || getSettings().currentMode;
  
  if (!code || !name || !type || !price || !quantity) {
    return res.status(400).json({ error: "表单参数不完整" });
  }

  try {
    const trades = loadTrades(mode);
    const watchlist = loadWatchlist();
    const initialCash = getInitialCash(mode);

    // 1. 手续费计算 (动态配置)
    const settings = getSettings();
    const tradeAmount = price * quantity;
    const commission = Math.max(settings.minCommission, Number((tradeAmount * settings.commissionRate).toFixed(2)));
    const transferFee = Number((tradeAmount * settings.transferFeeRate).toFixed(2));
    const stampDuty = type === "SELL" ? Number((tradeAmount * settings.stampDutyRate).toFixed(2)) : 0;
    const totalFee = Number((commission + transferFee + stampDuty).toFixed(2));

    // 2. 校验资金或持仓量
    // 重新推导当前持仓和可用现金，检验是否有交易资格
    let availableCash = initialCash;
    let ownedQty = 0;

    trades.forEach(t => {
      const amt = t.price * t.quantity;
      if (t.type === "BUY") {
        availableCash -= (amt + t.totalFee);
        if (t.code === code) ownedQty += t.quantity;
      } else {
        availableCash += (amt - t.totalFee);
        if (t.code === code) ownedQty -= t.quantity;
      }
    });

    if (type === "BUY") {
      if (availableCash < (tradeAmount + totalFee)) {
        return res.status(400).json({ error: `可用资金不足！需要 ${(tradeAmount + totalFee).toFixed(2)} 元，可用余额为 ${availableCash.toFixed(2)} 元。` });
      }
    } else {
      if (ownedQty < quantity) {
        return res.status(400).json({ error: `持仓不足！当前仅持有该股 ${ownedQty} 股，无法卖出 ${quantity} 股。` });
      }
    }

    // 3. 构建当前规则快照 (Snapshot)
    const matchedStock = watchlist.find(s => s.code === code);
    const historyKLine = loadHistoryKLine(code);
    
    // 如果没有，直接现场计算一波
    const evalResult = evaluateStock(code, name, price, historyKLine, availableCash);
    
    // 是否在交易时间内 (9:30-11:30, 13:00-15:00)
    const now = new Date();
    const hour = now.getHours();
    const min = now.getMinutes();
    const totalMin = hour * 60 + min;
    const inTradingTime = (totalMin >= 9 * 60 + 30 && totalMin <= 11 * 60 + 30) || (totalMin >= 13 * 60 && totalMin <= 15 * 60);

    const snapshot = {
      group: matchedStock ? matchedStock.group : evalResult.group,
      stage: matchedStock ? matchedStock.stage : evalResult.stage,
      ma5: evalResult.indicators.ma5,
      deviation5: evalResult.indicators.deviation5,
      bigCandlePct: evalResult.indicators.bigCandlePct,
      ma5Upward: evalResult.indicators.ma5Upward,
      cashSufficient: availableCash >= (price * 100),
      inTradingTime
    };

    // 审计此笔买入交易是否违规
    let rulesConclusion: "符合规则" | "违规交易" | "部分不符" | "其他" = "符合规则";
    let violationTags: string[] = [];
    
    if (type === "BUY") {
      const audit = auditBuyTrade(code, name, price, historyKLine, availableCash);
      rulesConclusion = audit.rulesConclusion;
      violationTags = audit.violationTags;
    } else {
      rulesConclusion = "符合规则";
    }

    // 创建交易历史对象
    const dateStr = now.toISOString().split("T")[0];
    const timeStr = now.toTimeString().split(" ")[0];

    const newTrade: TradeLog = {
      id: "T" + Date.now().toString().substring(6),
      code,
      name,
      type: type as "BUY" | "SELL",
      date: dateStr,
      time: timeStr,
      price,
      quantity,
      amount: tradeAmount,
      commission,
      stampDuty,
      transferFee,
      totalFee,
      reason,
      remark,
      snapshot,
      rulesConclusion,
      violationTags
    };

    trades.push(newTrade);
    writeTrades(trades, mode);

    // 交易完成后，自动将此股票分组更改为“持仓”分组
    if (type === "BUY" && matchedStock) {
      matchedStock.group = "持仓";
      writeWatchlist(watchlist);
    } else if (type === "SELL" && ownedQty - quantity <= 0 && matchedStock) {
      // 卖光了，移除持仓分组回到观察
      matchedStock.group = "观察";
      writeWatchlist(watchlist);
    }

    res.json({ success: true, trade: newTrade });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 11. 交易流水编辑与删除
app.post("/api/trades/delete", (req, res) => {
  const { id, mode } = req.body;
  if (!id) return res.status(400).json({ error: "交易流水ID缺失" });
  
  const activeMode = mode || getSettings().currentMode;
  const trades = loadTrades(activeMode);
  const updated = trades.filter(t => t.id !== id);
  writeTrades(updated, activeMode);
  res.json({ success: true });
});

// 11.5 交易流水编辑更新
app.post("/api/trades/update", (req, res) => {
  const { id, mode, price, quantity, date, time, reason, remark, rulesConclusion, violationTags, commission, stampDuty, transferFee, totalFee } = req.body;
  if (!id) return res.status(400).json({ error: "交易流水ID缺失" });

  const activeMode = mode || getSettings().currentMode;
  const trades = loadTrades(activeMode);
  const idx = trades.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: "未找到该笔交易记录" });

  const t = trades[idx];
  if (price !== undefined) t.price = Number(price);
  if (quantity !== undefined) t.quantity = Number(quantity);
  if (date !== undefined) t.date = String(date);
  if (time !== undefined) t.time = String(time);
  if (reason !== undefined) t.reason = String(reason);
  if (remark !== undefined) t.remark = String(remark);
  if (rulesConclusion !== undefined) t.rulesConclusion = rulesConclusion;
  if (violationTags !== undefined) {
    t.violationTags = Array.isArray(violationTags) ? violationTags : JSON.parse(violationTags);
  }

  // 重新计算并同步小额费用
  const tradeAmount = t.price * t.quantity;
  t.amount = tradeAmount;

  if (commission !== undefined) t.commission = Number(commission);
  if (stampDuty !== undefined) t.stampDuty = Number(stampDuty);
  if (transferFee !== undefined) t.transferFee = Number(transferFee);
  if (totalFee !== undefined) {
    t.totalFee = Number(totalFee);
  } else {
    // 重新根据配置自动计算
    const settings = getSettings();
    const calculatedCommission = Math.max(settings.minCommission, Number((tradeAmount * settings.commissionRate).toFixed(2)));
    const calculatedTransferFee = Number((tradeAmount * settings.transferFeeRate).toFixed(2));
    const calculatedStampDuty = t.type === "SELL" ? Number((tradeAmount * settings.stampDutyRate).toFixed(2)) : 0;
    
    t.commission = commission !== undefined ? Number(commission) : calculatedCommission;
    t.stampDuty = stampDuty !== undefined ? Number(stampDuty) : calculatedStampDuty;
    t.transferFee = transferFee !== undefined ? Number(transferFee) : calculatedTransferFee;
    t.totalFee = Number((t.commission + t.transferFee + t.stampDuty).toFixed(2));
  }

  writeTrades(trades, activeMode);
  res.json({ success: true, trade: t });
});

// 11.8 获取聚合复盘上下文数据
app.get("/api/reports/context", (req, res) => {
  const mode = (req.query.mode as "simulation" | "real") || getSettings().currentMode;
  const trades = loadTrades(mode);
  const watchlist = loadWatchlist();
  const initialCash = getInitialCash(mode);

  // 1. 今日交易记录
  const todayStr = new Date().toISOString().split("T")[0];
  const todayTrades = trades.filter(t => t.date === todayStr);

  // 2. 当前持仓与盈亏等
  const activePositions: Record<string, Position> = {};
  const firstPurchaseDates: Record<string, string> = {};
  let cashBalance = initialCash;
  let totalRealizedPnL = 0;

  const priceMap: Record<string, number> = {};
  const maMap: Record<string, number> = {};
  watchlist.forEach(s => {
    priceMap[s.code] = s.price;
    maMap[s.code] = s.ma5;
  });

  for (const trade of trades) {
    const tradeAmount = trade.price * trade.quantity;
    const tradeFee = trade.totalFee;

    if (trade.type === "BUY") {
      cashBalance -= (tradeAmount + tradeFee);
      if (!activePositions[trade.code]) {
        firstPurchaseDates[trade.code] = trade.date;
        activePositions[trade.code] = {
          code: trade.code,
          name: trade.name,
          quantity: trade.quantity,
          availableQuantity: trade.quantity,
          avgCost: trade.price,
          currentPrice: trade.price,
          marketValue: tradeAmount,
          floatingPnL: 0,
          floatingPnLPct: 0,
          ma5: maMap[trade.code] || 0,
          deviation5: 0,
          holdDays: 1,
          advice: "趋势未破，继续持有观察",
          riskLevel: "normal"
        };
      } else {
        const p = activePositions[trade.code];
        const totalQty = p.quantity + trade.quantity;
        const totalCost = (p.avgCost * p.quantity) + tradeAmount + tradeFee;
        p.avgCost = Number((totalCost / totalQty).toFixed(4));
        p.quantity = totalQty;
        p.availableQuantity = totalQty;
      }
    } else {
      const p = activePositions[trade.code];
      if (p) {
        const sellAmount = tradeAmount - tradeFee;
        const buyCost = p.avgCost * trade.quantity;
        const realizedPnL = sellAmount - buyCost;
        totalRealizedPnL += realizedPnL;
        cashBalance += sellAmount;

        const remainingQty = p.quantity - trade.quantity;
        if (remainingQty <= 0) {
          delete activePositions[trade.code];
          delete firstPurchaseDates[trade.code];
        } else {
          p.quantity = remainingQty;
          p.availableQuantity = remainingQty;
        }
      }
    }
  }

  const getDaysBetween = (dateStr1: string, dateStr2: string): number => {
    try {
      const d1 = new Date(dateStr1);
      const d2 = new Date(dateStr2);
      const diffTime = Math.abs(d2.getTime() - d1.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays || 1;
    } catch (e) {
      return 1;
    }
  };

  Object.keys(activePositions).forEach(code => {
    const p = activePositions[code];
    const buyDate = firstPurchaseDates[code] || todayStr;
    p.holdDays = getDaysBetween(buyDate, todayStr);
  });

  const positionsList: Position[] = [];
  let holdingValue = 0;
  let totalFloatingPnL = 0;

  for (const code of Object.keys(activePositions)) {
    const p = activePositions[code];
    const livePrice = priceMap[code] || p.currentPrice;
    p.currentPrice = livePrice;
    p.marketValue = Number((livePrice * p.quantity).toFixed(2));
    p.floatingPnL = Number((p.marketValue - (p.avgCost * p.quantity)).toFixed(2));
    p.floatingPnLPct = Number(((p.floatingPnL / (p.avgCost * p.quantity)) * 100).toFixed(2));
    
    holdingValue += p.marketValue;
    totalFloatingPnL += p.floatingPnL;

    p.ma5 = maMap[code] || p.ma5;
    if (p.ma5 > 0) {
      p.deviation5 = Number((((livePrice - p.ma5) / p.ma5) * 100).toFixed(2));
    }

    // 纠错与风险状态 (连续未站上5日线判定)
    let consecutiveUnderMA5 = 0;
    if (livePrice < p.ma5) {
      consecutiveUnderMA5 = 1;
      const hist = loadHistoryKLine(code);
      if (hist && hist.length > 0) {
        const sortedHist = [...hist].sort((a, b) => a.date.localeCompare(b.date));
        for (let idx = sortedHist.length - 1; idx >= 0; idx--) {
          if (idx < 4) break;
          const slice = sortedHist.slice(idx - 4, idx + 1);
          const sum = slice.reduce((acc, item) => acc + Number(item.close), 0);
          const histMA5 = sum / 5;
          const histClose = Number(sortedHist[idx].close);
          if (histClose < histMA5) {
            consecutiveUnderMA5++;
          } else {
            break;
          }
        }
      }
    }

    if (livePrice < p.ma5) {
      if (consecutiveUnderMA5 >= 3) {
        p.advice = "连续多日未站回 MA5：清仓提醒！";
        p.riskLevel = "danger";
      } else {
        p.advice = "跌破 MA5：风险提醒！";
        p.riskLevel = "danger";
      }
    } else if (p.deviation5 > 7.0) {
      p.advice = "远离 MA5：止盈提醒！";
      p.riskLevel = "warning";
    } else {
      p.advice = "趋势未破：继续观察。";
      p.riskLevel = "normal";
    }

    positionsList.push(p);
  }

  // 3. 大盘强弱指标 (基于自选池/成分股)
  const totalStocks = watchlist.length;
  let upStocks = 0;
  let downStocks = 0;
  let aboveMA5Count = 0;

  watchlist.forEach(s => {
    if (s.pct > 0) upStocks++;
    else if (s.pct < 0) downStocks++;
    if (s.price > s.ma5 && s.ma5 > 0) aboveMA5Count++;
  });

  const riseRatio = totalStocks > 0 ? Number(((upStocks / totalStocks) * 100).toFixed(0)) : 50;
  const aboveMA5Ratio = totalStocks > 0 ? Number(((aboveMA5Count / totalStocks) * 100).toFixed(0)) : 50;
  const bullishIndex = Number(((riseRatio + aboveMA5Ratio) / 2).toFixed(0));
  const marketStrength = bullishIndex > 60 ? "强" : bullishIndex < 40 ? "弱" : "中";

  // 4. 板块/行业分类
  function getStockSector(name: string, code: string): string {
    if (name.includes("银行")) return "银行金融";
    if (name.includes("证券") || name.includes("保险") || name.includes("平安")) return "非银金融";
    if (name.includes("酒") || name.includes("伊利") || name.includes("中免")) return "食品消费";
    if (name.includes("药") || name.includes("医")) return "医药生物";
    if (name.includes("电力") || name.includes("神华") || name.includes("石油")) return "能源公用";
    if (name.includes("科技") || name.includes("通讯") || name.includes("电子") || name.includes("歌尔")) return "科技半导体";
    if (name.includes("车") || name.includes("比亚迪")) return "新能源汽车";
    if (name.includes("建") || name.includes("万科") || name.includes("钢")) return "基建周期";
    return "综合行业";
  }

  const sectorGroups: Record<string, { name: string; sumPct: number; count: number; aboveMA5: number; totalVolume: number }> = {};
  watchlist.forEach(s => {
    const sec = getStockSector(s.name, s.code);
    if (!sectorGroups[sec]) {
      sectorGroups[sec] = { name: sec, sumPct: 0, count: 0, aboveMA5: 0, totalVolume: 0 };
    }
    const group = sectorGroups[sec];
    group.sumPct += s.pct;
    group.count++;
    if (s.price > s.ma5 && s.ma5 > 0) group.aboveMA5++;
    group.totalVolume += s.volume;
  });

  const sectors = Object.values(sectorGroups).map(g => ({
    sectorName: g.name,
    avgChangePct: Number((g.sumPct / g.count).toFixed(2)),
    aboveMA5Ratio: Number(((g.aboveMA5 / g.count) * 100).toFixed(0)),
    totalVolume: g.totalVolume,
    totalCount: g.count,
    hotCandidate: false
  })).sort((a, b) => b.avgChangePct - a.avgChangePct);

  if (sectors.length > 0) {
    sectors[0].hotCandidate = true;
  }

  // 5. 个股发散、粘合、行动状态
  const holdingDeviation = positionsList.map(p => {
    let stateLabel = "温和发散";
    if (p.deviation5 > 5.0) {
      stateLabel = "向上发散 (远离均线)";
    } else if (p.deviation5 < -3.0) {
      stateLabel = "向下破位 (低于均线)";
    } else if (Math.abs(p.deviation5) <= 1.5) {
      stateLabel = "窄幅粘合 (贴近均线)";
    }
    return {
      code: p.code,
      name: p.name,
      currentPrice: p.currentPrice || 0,
      ma5: p.ma5 || 0,
      deviationPct: p.deviation5 || 0,
      stateLabel,
      recommendedAction: p.advice || "趋势未破，继续观察",
      riskLevel: p.riskLevel
    };
  });

  // 6. 今日合规统计
  const todayBuyTrades = todayTrades.filter(t => t.type === "BUY");
  const compliantCount = todayBuyTrades.filter(t => t.rulesConclusion === "符合规则").length;
  const complianceRate = todayBuyTrades.length > 0 ? Number(((compliantCount / todayBuyTrades.length) * 100).toFixed(0)) : 100;

  const summaryStatistics = {
    complianceRate
  };

  res.json({
    todayTrades,
    currentPositions: positionsList,
    marketSnapshot: {
      totalStocks,
      upStocks,
      downStocks,
      riseRatio,
      aboveMA5Count,
      aboveMA5Ratio,
      bullishIndex,
      marketStrength,
      trendStrength: bullishIndex > 60 ? "strong" : bullishIndex < 40 ? "weak" : "neutral",
      riseCount: upStocks,
      fallCount: downStocks
    },
    sectors,
    holdingDeviation,
    summaryStatistics
  });
});

// 12. 交易复盘审计接口
app.get("/api/reports/audit", (req, res) => {
  const mode = (req.query.mode as "simulation" | "real") || getSettings().currentMode;
  const trades = loadTrades(mode);
  const buyTrades = trades.filter(t => t.type === "BUY");
  const totalBuy = buyTrades.length;
  
  if (totalBuy === 0) {
    return res.json({ complianceRate: 100, compliantCount: 0, totalBuy: 0, violationsList: [] });
  }

  const compliantCount = buyTrades.filter(t => t.rulesConclusion === "符合规则").length;
  const complianceRate = Number(((compliantCount / totalBuy) * 100).toFixed(2));
  
  const violationsList = buyTrades.filter(t => t.rulesConclusion !== "符合规则").map(t => ({
    id: t.id,
    code: t.code,
    name: t.name,
    date: t.date,
    price: t.price,
    rulesConclusion: t.rulesConclusion,
    tags: t.violationTags
  }));

  res.json({ complianceRate, compliantCount, totalBuy, violationsList });
});

// 13. 保存/获取复盘报告 (日报、周报、月报)
const REPORTS_BASE = path.join(process.cwd(), "data", "reports");

app.post("/api/reports/save", (req, res) => {
  const report: ReviewReport = req.body;
  if (!report.type || !report.date || !report.id) {
    return res.status(400).json({ error: "报告基本信息缺失" });
  }

  try {
    const reportPath = path.join(REPORTS_BASE, report.type, `${report.date}.json`);
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), "utf8");
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/reports/list", (req, res) => {
  const { type } = req.query;
  if (!type || (type !== "daily" && type !== "weekly" && type !== "monthly")) {
    return res.status(400).json({ error: "复盘类型错误" });
  }

  try {
    const dir = path.join(REPORTS_BASE, type);
    const files = fs.readdirSync(dir);
    const reports: ReviewReport[] = [];

    files.forEach(file => {
      if (file.endsWith(".json")) {
        const content = fs.readFileSync(path.join(dir, file), "utf8");
        reports.push(JSON.parse(content));
      }
    });

    // 按日期降序
    reports.sort((a, b) => b.date.localeCompare(a.date));
    res.json({ reports });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});


// Vite 整合部分 - 必须在所有 API 路由注册之后！
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[交易纪律系统] 服务端启动成功，监听地址: http://0.0.0.0:${PORT}`);
  });
}

startServer();
