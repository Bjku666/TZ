import fs from "fs";
import path from "path";

// 确保目录存在
const DATA_DIR = path.join(process.cwd(), "data");
const HISTORY_DIR = path.join(DATA_DIR, "history");
const TRADES_DIR = path.join(DATA_DIR, "trades");
const RUNTIME_DIR = path.join(DATA_DIR, "runtime");
const PROCESSED_DIR = path.join(DATA_DIR, "processed");
const REPORTS_DIR = path.join(DATA_DIR, "reports");
const REPORTS_DAILY = path.join(REPORTS_DIR, "daily");
const REPORTS_WEEKLY = path.join(REPORTS_DIR, "weekly");
const REPORTS_MONTHLY = path.join(REPORTS_DIR, "monthly");
const BACKUPS_DIR = path.join(DATA_DIR, "backups");

export function initStorage() {
  const dirs = [
    DATA_DIR,
    HISTORY_DIR,
    TRADES_DIR,
    RUNTIME_DIR,
    PROCESSED_DIR,
    REPORTS_DIR,
    REPORTS_DAILY,
    REPORTS_WEEKLY,
    REPORTS_MONTHLY,
    BACKUPS_DIR
  ];
  dirs.forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  });

  // 初始化空配置文件
  const settingsFile = path.join(RUNTIME_DIR, "settings.json");
  if (!fs.existsSync(settingsFile)) {
    fs.writeFileSync(settingsFile, JSON.stringify({ initialCash: 100000 }, null, 2));
  }
}

/**
 * 极简、健壮的 CSV 解析工具
 */
export function parseCSV(content: string): any[] {
  if (!content) return [];
  const lines = content.split(/\r?\n/);
  if (lines.length === 0) return [];
  const headers = lines[0].split(',').map(h => h.trim());
  const result: any[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const values: string[] = [];
    let insideQuote = false;
    let currentVal = '';
    
    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      if (char === '"') {
        insideQuote = !insideQuote;
      } else if (char === ',' && !insideQuote) {
        values.push(currentVal.trim());
        currentVal = '';
      } else {
        currentVal += char;
      }
    }
    values.push(currentVal.trim());
    
    if (values.length < headers.length) continue;
    const obj: any = {};
    headers.forEach((header, index) => {
      let val: any = values[index];
      if (val.startsWith('"') && val.endsWith('"')) {
        val = val.substring(1, val.length - 1);
      }
      // 处理转义的双引号
      val = val.replace(/""/g, '"');
      
      // 转换类型
      if (val === 'true') val = true;
      else if (val === 'false') val = false;
      else if (val === '') val = '';
      else if (!isNaN(Number(val)) && val !== '') val = Number(val);
      
      obj[header] = val;
    });
    result.push(obj);
  }
  return result;
}

/**
 * 将对象数组转换为 CSV 字符串
 */
export function toCSV(headers: string[], rows: any[]): string {
  const headerLine = headers.join(',');
  const rowLines = rows.map(row => {
    return headers.map(header => {
      let val = row[header];
      if (val === undefined || val === null) {
        return '';
      }
      if (Array.isArray(val)) {
        val = JSON.stringify(val);
      }
      const valStr = String(val);
      if (valStr.includes(',') || valStr.includes('"') || valStr.includes('\n')) {
        return `"${valStr.replace(/"/g, '""')}"`;
      }
      return valStr;
    }).join(',');
  });
  return [headerLine, ...rowLines].join('\n');
}

/**
 * 写入 CSV 前自动备份旧文件
 */
export function safeWriteCSV(filePath: string, headers: string[], rows: any[]) {
  if (fs.existsSync(filePath)) {
    try {
      const fileName = path.basename(filePath, path.extname(filePath));
      const ext = path.extname(filePath);
      const timestamp = new Date().toISOString().replace(/[-:T]/g, "").substring(0, 14);
      const backupPath = path.join(BACKUPS_DIR, `${fileName}_${timestamp}${ext}`);
      fs.copyFileSync(filePath, backupPath);
    } catch (err) {
      console.error("备份失败:", err);
    }
  }
  const content = toCSV(headers, rows);
  fs.writeFileSync(filePath, content, "utf8");
}

// 缓存历史 K 线数据到 CSV 文件
export function saveHistoryKLine(code: string, rows: any[]) {
  const filePath = path.join(HISTORY_DIR, `${code}.csv`);
  const headers = ["date", "open", "high", "low", "close", "volume", "amount"];
  const formattedRows = rows.map(r => ({
    date: r.date,
    open: Number(r.open),
    high: Number(r.high),
    low: Number(r.low),
    close: Number(r.close),
    volume: Number(r.volume),
    amount: Number(r.amount)
  }));
  // 历史 K 线直接覆盖，不作为主要资产备份
  const content = toCSV(headers, formattedRows);
  fs.writeFileSync(filePath, content, "utf8");
}

export function loadHistoryKLine(code: string): any[] {
  const filePath = path.join(HISTORY_DIR, `${code}.csv`);
  if (!fs.existsSync(filePath)) return [];
  const content = fs.readFileSync(filePath, "utf8");
  return parseCSV(content);
}

export function checkHistoryStatus(code: string): string {
  const filePath = path.join(HISTORY_DIR, `${code}.csv`);
  if (!fs.existsSync(filePath)) return "缺少历史K线";
  const rows = loadHistoryKLine(code);
  if (rows.length < 20) return "数据不足";
  return "已有缓存";
}
