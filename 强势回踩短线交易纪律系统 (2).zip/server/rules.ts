import { StockGroup, StockStage, RiskLevel } from "../src/types";

/**
 * 判断是否为沪深主板A股
 */
export function isMainBoard(code: string): boolean {
  if (!code) return false;
  
  // 排除京东方A
  if (code === "000725") return false;

  // 上海主板: 600, 601, 603, 605
  if (code.startsWith("600") || code.startsWith("601") || code.startsWith("603") || code.startsWith("605")) {
    return true;
  }

  // 深圳主板: 000, 001, 002
  if (code.startsWith("000") || code.startsWith("001") || code.startsWith("002")) {
    return true;
  }

  return false;
}

/**
 * 判断是否排除股票 (ST, 创业板, 科创板, 北交所, 京东方A等)
 */
export function shouldExclude(code: string, name: string): { exclude: boolean; reason: string } {
  if (!code) return { exclude: true, reason: "代码为空" };
  
  const upperName = name ? name.toUpperCase() : "";
  if (upperName.includes("ST") || upperName.includes("*ST")) {
    return { exclude: true, reason: "排除 ST/*ST 股票" };
  }

  if (code === "000725") {
    return { exclude: true, reason: "排除京东方A (高容量但弹性弱)" };
  }

  if (code.startsWith("300") || code.startsWith("301")) {
    return { exclude: true, reason: "排除创业板" };
  }

  if (code.startsWith("688") || code.startsWith("689")) {
    return { exclude: true, reason: "排除科创板" };
  }

  // 北交所 8/4/920
  if (code.startsWith("8") || code.startsWith("4") || code.startsWith("920")) {
    return { exclude: true, reason: "排除北交所" };
  }

  if (!isMainBoard(code)) {
    return { exclude: true, reason: "非沪深主板A股" };
  }

  return { exclude: false, reason: "" };
}

/**
 * 计算技术指标 (MA5, MA10, MA20, MA5向上, 最近大阳线等)
 * historyKLine 为按时间升序排列的K线列表
 */
export function calculateIndicators(currentPrice: number, historyKLine: any[]): {
  ma5: number;
  ma10: number;
  ma20: number;
  deviation5: number;
  bigCandlePct: number;
  ma5Upward: boolean;
  historyStatus: "已有缓存" | "数据不足" | "缺少历史K线";
} {
  if (!historyKLine || historyKLine.length === 0) {
    return {
      ma5: 0,
      ma10: 0,
      ma20: 0,
      deviation5: 0,
      bigCandlePct: 0,
      ma5Upward: false,
      historyStatus: "缺少历史K线"
    };
  }

  // 计算大阳线 (近20日最大涨幅，这里按阳线 (Close - Open) / Open 计算，或者 (Close - PrevClose) / PrevClose)
  let maxCandleGain = 0;
  const len = historyKLine.length;
  const startIdx = Math.max(0, len - 20);
  
  for (let i = startIdx; i < len; i++) {
    const k = historyKLine[i];
    const open = Number(k.open);
    const close = Number(k.close);
    if (open > 0) {
      // 阳线涨幅
      const gain = (close - open) / open;
      if (gain > maxCandleGain) {
        maxCandleGain = gain;
      }
    }
    // 也可以检查与前一天收盘价的涨幅
    if (i > 0) {
      const prevClose = Number(historyKLine[i - 1].close);
      if (prevClose > 0) {
        const pctGain = (close - prevClose) / prevClose;
        if (pctGain > maxCandleGain) {
          maxCandleGain = pctGain;
        }
      }
    }
  }

  // 组合历史 K 线与当前价
  // 如果 K 线里没有包含今天，或者今天还没收盘，我们将当前价加入序列作为最新的“收盘”
  const closes = historyKLine.map(k => Number(k.close));
  
  // 简单的判定是否需要追加
  closes.push(currentPrice);

  if (closes.length < 5) {
    return {
      ma5: 0,
      ma10: 0,
      ma20: 0,
      deviation5: 0,
      bigCandlePct: maxCandleGain * 100,
      ma5Upward: false,
      historyStatus: "数据不足"
    };
  }

  const getMA = (arr: number[], periods: number): number => {
    if (arr.length < periods) return 0;
    const slice = arr.slice(arr.length - periods);
    const sum = slice.reduce((a, b) => a + b, 0);
    return Number((sum / periods).toFixed(2));
  };

  const ma5 = getMA(closes, 5);
  const ma10 = getMA(closes, 10);
  const ma20 = getMA(closes, 20);

  // 计算昨日 MA5 (包含昨日，不包含当前价的倒数第二序列)
  const prevCloses = closes.slice(0, closes.length - 1);
  const yesterdayMa5 = getMA(prevCloses, 5);
  const ma5Upward = yesterdayMa5 > 0 ? ma5 > yesterdayMa5 : false;

  // 偏离率
  const deviation5 = ma5 > 0 ? Number((((currentPrice - ma5) / ma5) * 100).toFixed(2)) : 0;

  return {
    ma5,
    ma10,
    ma20,
    deviation5,
    bigCandlePct: Number((maxCandleGain * 100).toFixed(2)),
    ma5Upward,
    historyStatus: closes.length >= 20 ? "已有缓存" : "数据不足"
  };
}

/**
 * 核心分类决策规则
 */
export function evaluateStock(
  code: string,
  name: string,
  price: number,
  historyKLine: any[],
  availableCash: number
): {
  group: StockGroup;
  stage: StockStage;
  riskLevel: RiskLevel;
  canBuy: boolean;
  reason: string;
  reminder: string;
  indicators: any;
} {
  // 1. 范围筛选
  const exclusion = shouldExclude(code, name);
  if (exclusion.exclude) {
    return {
      group: "初筛",
      stage: "缺少历史K线",
      riskLevel: "danger",
      canBuy: false,
      reason: exclusion.reason,
      reminder: "不满足交易范围约束",
      indicators: { ma5: 0, ma10: 0, ma20: 0, deviation5: 0, bigCandlePct: 0, ma5Upward: false, historyStatus: "缺少历史K线" }
    };
  }

  // 2. 指标计算
  const ind = calculateIndicators(price, historyKLine);

  if (ind.historyStatus === "缺少历史K线" || ind.historyStatus === "数据不足") {
    return {
      group: "初筛",
      stage: "缺少历史K线",
      riskLevel: "warning",
      canBuy: false,
      reason: "缺少或不足历史K线，无法计算MA指标",
      reminder: "请在「历史K线管理」中补全K线数据",
      indicators: ind
    };
  }

  // 3. 大阳线判定: 近10-20日有 ≥5% 阳线
  if (ind.bigCandlePct < 5.0) {
    return {
      group: "初筛",
      stage: "初筛通过",
      riskLevel: "normal",
      canBuy: false,
      reason: `初筛通过，但近20日无≥5%大阳线 (最大仅 ${ind.bigCandlePct}%)`,
      reminder: "等待出现强势大阳线启动信号",
      indicators: ind
    };
  }

  // 4. 买点区间与分级逻辑 (初筛 / 观察 / 待买)
  let group: StockGroup = "初筛";
  let stage: StockStage = "初筛通过";
  let riskLevel: RiskLevel = "normal";
  let canBuy = false;
  let reason = "";
  let reminder = "";

  const hasBigCandle = ind.bigCandlePct >= 5.0;
  const hasMa5Upward = ind.ma5Upward;
  const isAboveMa5 = price > ind.ma5;

  if (hasBigCandle && hasMa5Upward && isAboveMa5) {
    if (ind.deviation5 <= 2.0) {
      // 严格符合 0% ~ 2% 黄金买点
      group = "待买";
      stage = "待买观察";
      canBuy = true;
      riskLevel = "normal";
      reason = `严格符合强势回踩买点 (偏离度 ${ind.deviation5}%，MA5向上，且近20日有大阳线)`;
      reminder = "当前处于极佳低吸黄金买点，买入纪律执行中";
    } else {
      // 股价在 MA5 上方且大于 2%，属于“等回踩”阶段
      group = "观察";
      stage = "等回踩";
      riskLevel = "normal";
      reason = `处于强势观察期 (偏离度 ${ind.deviation5}%，MA5向上，且近20日有大阳线)`;
      reminder = "等待股价回落至 0%~2% 买入金区";
    }
  } else {
    // 不符合观察/待买条件，一律归入“初筛”
    group = "初筛";
    stage = "初筛通过";
    riskLevel = "normal";
    
    const issues: string[] = [];
    if (!hasBigCandle) issues.push(`近20日无≥5%阳线(最大仅${ind.bigCandlePct}%)`);
    if (!hasMa5Upward) issues.push("5日均线未向上");
    if (!isAboveMa5) issues.push(`股价低于5日线(偏离度${ind.deviation5}%)`);

    reason = `初筛标的，尚未启动或偏离指标不符 (${issues.join(", ")})`;
    reminder = "暂不符合纪律介入条件，仅作为初筛基础池关注";
  }

  return {
    group,
    stage,
    riskLevel,
    canBuy,
    reason,
    reminder,
    indicators: ind
  };
}

/**
 * 校验买入交易是否符合规则
 */
export function auditBuyTrade(
  code: string,
  name: string,
  price: number,
  historyKLine: any[],
  availableCash: number
): {
  rulesConclusion: "符合规则" | "违规交易" | "部分不符";
  violationTags: string[];
} {
  const tags: string[] = [];
  
  // 1. 板块
  if (!isMainBoard(code)) {
    tags.push("非沪深主板A股");
  }
  
  // 排除 ST, 创业板, 京东方A等
  const exc = shouldExclude(code, name);
  if (exc.exclude && exc.reason) {
    tags.push(exc.reason);
  }

  const ind = calculateIndicators(price, historyKLine);
  if (ind.historyStatus !== "已有缓存") {
    tags.push("缺少历史K线");
  } else {
    // 2. 强势启动特征
    if (ind.bigCandlePct < 5.0) {
      tags.push("近20日无≥5%阳线");
    }
    // 3. MA5 向上
    if (!ind.ma5Upward) {
      tags.push("MA5未向上");
    }
    // 4. 回踩买点区间 (0% - 2%)
    if (ind.deviation5 < 0) {
      tags.push("跌破MA5买入");
    } else if (ind.deviation5 > 2.0) {
      tags.push("偏离度过高追涨");
    }
  }

  return {
    rulesConclusion: tags.length === 0 ? "符合规则" : tags.length <= 2 ? "部分不符" : "违规交易",
    violationTags: tags
  };
}
